//
//  CustomClass.h
//  tableViewSelectedSize
//
//  Created by Revo Tech on 6/10/16.
//  Copyright © 2016 Revo Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface CustomClass : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *deliver_address;
@property (nonatomic, strong) NSString *phone;
@property (nonatomic, strong) UIImage *imageV;
@property (nonatomic, strong) UIImage *imageV1;

@property (nonatomic, strong) UIButton *deliverbtn;
@property (nonatomic, strong) UIButton *edit;
@property (nonatomic, strong) UIButton *del;

@end
