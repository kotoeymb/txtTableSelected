//
//  ViewController.m
//  tableViewSelectedSize
//
//  Created by Revo Tech on 6/10/16.
//  Copyright © 2016 Revo Tech. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"
#import "CustomClass.h"

@interface ViewController () < UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *table_view;
@property (nonatomic, strong) NSArray *listOfElements;
@property (nonatomic, readonly) UINib *intelligentCellNib;
@property (nonatomic, retain) NSIndexPath *expandedCellIndexPath;
@property (nonatomic) CGFloat expandedCellHeight;

@end

@implementation ViewController
@synthesize intelligentCellNib = intelligentCellNib_;
@synthesize expandedCellHeight = expandedCellHeight_;
@synthesize expandedCellIndexPath = expandedCellIndexPath_;

//- (void)dealloc {
//    [intelligentCellNib_ release];
//    self.expandedCellIndexPath = nil;
//    [super dealloc];
//}
//
#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self loadTableView];
    [self loadDataTableView];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void) loadTableView{
    
    _table_view.delegate = self;
    _table_view.dataSource = self;
    self.table_view.estimatedRowHeight = 80;
    self.table_view.rowHeight = UITableViewAutomaticDimension;
    
    [self.table_view setNeedsLayout];
    [self.table_view layoutIfNeeded];
    
    self.table_view.contentInset = UIEdgeInsetsMake(20, 0, 0, 0) ;// Status bar inset
    
}
-(void) loadDataTableView{
    
    CustomClass *cus1 = [CustomClass new];
    cus1.name = @" John Doe";
    cus1.deliver_address = @"459D #6A, New University Avenue Rd,.. ";
    cus1.phone = @"Phone 12345667 ";
    cus1.imageV = [UIImage imageNamed:@"Radio_Button-128.png"];
 //    cus1.deliverbtn = [UIColor]
    
    
    
 
    _listOfElements = [[NSArray alloc] initWithObjects:cus1, nil];
    [_table_view reloadData];
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return  _listOfElements.count;
    
}




-(UITableViewCell*) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    TableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"Cell_Id"];
    if (!cell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell_Id"];
        cell = [tableView dequeueReusableCellWithIdentifier:@"Cell_Id"];
    }
    cell.lbl_name.text = [[_listOfElements objectAtIndex:indexPath.row] name];
    cell.lbl_address.text = [[_listOfElements objectAtIndex:indexPath.row] deliver_address];
    cell.lbl_phone.text = [[_listOfElements objectAtIndex:indexPath.row] phone];
    cell.radiobutton.image = [[_listOfElements objectAtIndex:indexPath.row] imageV];
    
  //  cell.frame.size.height
  //   cell.imageViewImage.image = [[_listOfElements objectAtIndex:indexPath.row] imageV];
    
    return cell;

    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedIndexPath = indexPath;
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation: UITableViewRowAnimationNone];
    TableViewCell *cell = [self tableView:tableView
                                           cellForRowAtIndexPath:indexPath];
   
    cell.accessoryType = UITableViewCellAccessoryCheckmark;

//    NSString *selected = [_products objectAtIndex:[self getRealIndexFromIndexPath:indexPath]];
//    NSLog(@"%@", selected);
   //  cell.frame.size.height =
 [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    if ( flag == 1 && indexPath.row == index )
        return 50;
    else
        return 30;

    //    if (indexPath.row == 0) {
//        return 100;
//    }
//    else {
//        return 180;
//    }
//    UITableViewCell *cell = [self tableView:tableView
//                      cellForRowAtIndexPath:indexPath];
//    return cell.frame.size.height;
}

@end
