//
//  CustomClass.m
//  tableViewSelectedSize
//
//  Created by Revo Tech on 6/10/16.
//  Copyright © 2016 Revo Tech. All rights reserved.
//

#import "CustomClass.h"

@implementation CustomClass


@end
